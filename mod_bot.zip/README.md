# Bot de Moderação Premium (Python)

Este bot foi desenvolvido seguindo as especificações rigorosas de UI/UX minimalista e funcionalidades avançadas de moderação.

## 🎨 Identidade Visual
- **Cor Única:** Preto Sólido (#000000)
- **Componentes:** Uso exclusivo de Discord Components V2 (Buttons, Select Menus, Modals).
- **Estilo:** Premium, moderno e minimalista.

## 🛠️ Funcionalidades Implementadas
- **Moderação:** `/ban`, `/kick`, `/mute`, `/unmute`.
- **Advertências:** `/warn`, `/warnings`.
- **Utilidades:** `/clear`, `/lock`, `/unlock`, `/slowmode`, `/nuke`.
- **Automoderação:** Painel central via `/automod`.
- **Logs:** Configuração de canais via `/setup-logs`.

## 🚀 Como Rodar
1. Certifique-se de ter o Python 3.8+ instalado.
2. Instale a biblioteca necessária:
   ```bash
   pip install discord.py
   ```
3. Abra o arquivo `main.py` e insira seu Token do Discord no local indicado.
4. Execute o bot:
   ```bash
   python main.py
   ```

## 📝 Notas
- O bot utiliza **Slash Commands**. Certifique-se de que o bot tem permissão `applications.commands`.
- O sistema de banco de dados foi estruturado para ser facilmente integrado com SQLite ou MongoDB.
- Todas as interações de confirmação usam botões para evitar erros acidentais.
