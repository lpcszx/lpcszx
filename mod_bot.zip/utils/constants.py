import discord

# Cor padrão obrigatória: Preto Sólido
DEFAULT_COLOR = 0x000000

def create_embed(title=None, description=None, fields=None, footer_text="Sistema de Moderação Premium"):
    embed = discord.Embed(
        title=title,
        description=description,
        color=DEFAULT_COLOR
    )
    if fields:
        for name, value, inline in fields:
            embed.add_field(name=name, value=value, inline=inline)
    
    embed.set_footer(text=footer_text)
    return embed

class BaseView(discord.ui.View):
    def __init__(self, timeout=180):
        super().__init__(timeout=timeout)
