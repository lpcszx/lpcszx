import discord
from discord import app_commands
from discord.ext import commands
from utils.constants import create_embed

class LogConfigView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(
        placeholder="Escolha o tipo de log para configurar...",
        options=[
            discord.SelectOption(label="Mod Logs", value="mod"),
            discord.SelectOption(label="Message Logs", value="message"),
            discord.SelectOption(label="Automod Logs", value="automod"),
            discord.SelectOption(label="Security Logs", value="security"),
        ]
    )
    async def select_type(self, interaction: discord.Interaction, select: discord.ui.Select):
        view = discord.ui.View()
        channel_select = discord.ui.ChannelSelect(placeholder="Selecione o canal para estes logs...")
        
        async def channel_callback(inter: discord.Interaction):
            # Salvar configuração no DB
            channel = channel_select.values[0]
            await inter.response.send_message(f"Logs de `{select.values[0]}` configurados para {channel.mention}.", ephemeral=True)

        channel_select.callback = channel_callback
        view.add_item(channel_select)
        await interaction.response.send_message("Agora selecione o canal:", view=view, ephemeral=True)

class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="setup-logs", description="Configura os canais de log")
    async def setup_logs(self, interaction: discord.Interaction):
        view = LogConfigView()
        await interaction.response.send_message("Configuração de Logs Automáticos:", view=view, ephemeral=True)

    # Exemplo de listener de log
    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.author.bot:
            return
        # Lógica para enviar embed preto sólido para o canal de logs configurado
        pass

async def setup(bot):
    await bot.add_cog(Logs(bot))
