import discord
from discord import app_commands
from discord.ext import commands
from utils.constants import create_embed

class NukeConfirmView(discord.ui.View):
    def __init__(self, channel: discord.TextChannel):
        super().__init__(timeout=60)
        self.channel = channel

    @discord.ui.button(label="Nukear", style=discord.ButtonStyle.secondary)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Lógica de Nuke: Clona e deleta o antigo
        # new_channel = await self.channel.clone(reason="Nuke")
        # await self.channel.delete(reason="Nuke")
        # await new_channel.send(embed=create_embed(title="CANA NUKEADO", description="Este canal foi limpo e recriado."))
        await interaction.response.send_message("Canal nukearia agora (Simulação).", ephemeral=True)

    @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="Operação cancelada.", embed=None, view=None)

class Nuke(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="nuke", description="Limpeza extrema do canal (clona e deleta o antigo)")
    async def nuke(self, interaction: discord.Interaction):
        channel = interaction.channel
        
        fields = [
            ("Nome", f"{channel.name}", True),
            ("ID", f"`{channel.id}`", True),
            ("Categoria", f"{channel.category.name if channel.category else 'Nenhuma'}", True),
        ]
        
        embed = create_embed(
            title="⚠️ Confirmação de Nuke",
            description="Você está prestes a apagar todas as mensagens deste canal permanentemente através da recriação do mesmo.",
            fields=fields
        )
        
        view = NukeConfirmView(channel)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Nuke(bot))
