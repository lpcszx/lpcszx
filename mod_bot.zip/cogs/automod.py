import discord
from discord import app_commands
from discord.ext import commands
from utils.constants import create_embed

class AutomodPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        # Estados fictícios para demonstração
        self.anti_link = False
        self.anti_spam = False
        self.anti_invite = False

    def update_embed(self):
        desc = (
            f"🔗 **Anti-link:** {'`ATIVADO`' if self.anti_link else '`DESATIVADO`'}\n"
            f"⚡ **Anti-spam:** {'`ATIVADO`' if self.anti_spam else '`DESATIVADO`'}\n"
            f"✉️ **Anti-invite:** {'`ATIVADO`' if self.anti_invite else '`DESATIVADO`'}\n"
            f"🔠 **Caps:** `DESATIVADO`\n"
            f"👻 **Ghost Ping:** `DESATIVADO`"
        )
        return create_embed(title="Painel Central de Automoderação", description=desc)

    @discord.ui.button(label="Toggle Anti-link", style=discord.ButtonStyle.secondary)
    async def toggle_link(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.anti_link = not self.anti_link
        await interaction.response.edit_message(embed=self.update_embed(), view=self)

    @discord.ui.button(label="Toggle Anti-spam", style=discord.ButtonStyle.secondary)
    async def toggle_spam(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.anti_spam = not self.anti_spam
        await interaction.response.edit_message(embed=self.update_embed(), view=self)

    @discord.ui.button(label="Configurações Avançadas", style=discord.ButtonStyle.secondary)
    async def advanced(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Menu select para tipos de bloqueio, whitelist, etc.
        await interaction.response.send_message("Menu de configurações avançadas em desenvolvimento.", ephemeral=True)

class Automod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="automod", description="Abre o painel central de automoderação")
    async def automod(self, interaction: discord.Interaction):
        view = AutomodPanel()
        await interaction.response.send_message(embed=view.update_embed(), view=view, ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
        
        # Exemplo de Anti-invite
        invites = ["discord.gg/", "discord.com/invite/"]
        if any(invite in message.content.lower() for invite in invites):
            # Se o anti-invite estivesse ativo no DB
            # await message.delete()
            # await message.channel.send(f"{message.author.mention}, convites não são permitidos!", delete_after=5)
            pass

async def setup(bot):
    await bot.add_cog(Automod(bot))
