import discord
from discord import app_commands
from discord.ext import commands
from utils.constants import create_embed, DEFAULT_COLOR
import datetime

class BanModal(discord.ui.Modal, title='Detalhes do Banimento'):
    motivo = discord.ui.TextInput(
        label='Motivo',
        placeholder='Descreva o motivo do banimento...',
        style=discord.TextStyle.paragraph,
        required=True
    )
    duracao = discord.ui.TextInput(
        label='Duração (opcional)',
        placeholder='Ex: 7d, 30d, permanente',
        required=False
    )
    apagar_mensagens = discord.ui.TextInput(
        label='Apagar mensagens?',
        placeholder='1h / 24h / 7d',
        required=False,
        default='24h'
    )

    def __init__(self, target_user: discord.Member, staff: discord.Member):
        super().__init__()
        self.target_user = target_user
        self.staff = staff

    async def on_submit(self, interaction: discord.Interaction):
        fields = [
            ("Usuário", f"{self.target_user.mention}", True),
            ("ID", f"`{self.target_user.id}`", True),
            ("Staff", f"{self.staff.mention}", True),
            ("Motivo", f"{self.motivo.value}", False),
            ("Tempo", f"{self.duracao.value or 'Permanente'}", True),
            ("Limpeza", f"{self.apagar_mensagens.value}", True)
        ]
        
        embed = create_embed(
            title="Confirmação de Banimento",
            description="Revise as informações abaixo antes de confirmar.",
            fields=fields
        )

        view = ActionConfirmView(self.target_user, "ban", self.motivo.value)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class KickModal(discord.ui.Modal, title='Detalhes da Expulsão'):
    motivo = discord.ui.TextInput(
        label='Motivo',
        placeholder='Descreva o motivo da expulsão...',
        style=discord.TextStyle.paragraph,
        required=True
    )

    def __init__(self, target_user: discord.Member, staff: discord.Member):
        super().__init__()
        self.target_user = target_user
        self.staff = staff

    async def on_submit(self, interaction: discord.Interaction):
        # Preview conforme solicitado: conta criada, tempo no servidor, cargos
        created_at = self.target_user.created_at.strftime("%d/%m/%Y")
        joined_at = self.target_user.joined_at.strftime("%d/%m/%Y")
        roles = ", ".join([r.mention for r in self.target_user.roles[1:]]) or "Nenhum"

        fields = [
            ("Usuário", f"{self.target_user.mention}", True),
            ("ID", f"`{self.target_user.id}`", True),
            ("Conta Criada", f"{created_at}", True),
            ("Entrou em", f"{joined_at}", True),
            ("Cargos", f"{roles}", False),
            ("Motivo", f"{self.motivo.value}", False)
        ]
        
        embed = create_embed(
            title="Confirmação de Expulsão",
            description="Preview do usuário antes da expulsão.",
            fields=fields
        )

        view = ActionConfirmView(self.target_user, "kick", self.motivo.value)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class MuteModal(discord.ui.Modal, title='Detalhes do Silenciamento'):
    duracao = discord.ui.TextInput(
        label='Duração',
        placeholder='Ex: 10m, 1h, 1d',
        required=True
    )
    motivo = discord.ui.TextInput(
        label='Motivo',
        placeholder='Descreva o motivo...',
        style=discord.TextStyle.paragraph,
        required=True
    )

    def __init__(self, target_user: discord.Member):
        super().__init__()
        self.target_user = target_user

    async def on_submit(self, interaction: discord.Interaction):
        embed = create_embed(
            title="Confirmação de Mute",
            description=f"Deseja silenciar {self.target_user.mention} por `{self.duracao.value}`?\nMotivo: {self.motivo.value}"
        )
        view = ActionConfirmView(self.target_user, "mute", self.motivo.value, duration=self.duracao.value)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class ActionConfirmView(discord.ui.View):
    def __init__(self, target_user: discord.Member, action_type: str, reason: str, duration: str = None):
        super().__init__(timeout=60)
        self.target_user = target_user
        self.action_type = action_type
        self.reason = reason
        self.duration = duration

    @discord.ui.button(label="Confirmar", style=discord.ButtonStyle.secondary)
    async def confirm(self, interaction: discord.Interaction):
        # Lógica para cada ação
        action_text = ""
        if self.action_type == "ban":
            # await self.target_user.ban(reason=self.reason)
            action_text = "banido"
        elif self.action_type == "kick":
            # await self.target_user.kick(reason=self.reason)
            action_text = "expulso"
        elif self.action_type == "mute":
            # Lógica de timeout ou cargo
            action_text = "silenciado"

        embed = create_embed(
            title="Ação Concluída",
            description=f"O usuário {self.target_user.mention} foi {action_text} com sucesso."
        )
        await interaction.response.edit_message(embed=embed, view=None)

    @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction):
        await interaction.response.edit_message(content="Operação cancelada.", embed=None, view=None)

class UserSelectView(discord.ui.View):
    def __init__(self, action_type: str):
        super().__init__(timeout=60)
        self.action_type = action_type

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder="Selecione um usuário...", min_values=1, max_values=1)
    async def select_user(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        target_user = select.values[0]
        
        if target_user.guild_permissions.administrator:
            return await interaction.response.send_message("Você não pode punir um administrador.", ephemeral=True)
            
        if self.action_type == "ban":
            await interaction.response.send_modal(BanModal(target_user, interaction.user))
        elif self.action_type == "kick":
            await interaction.response.send_modal(KickModal(target_user, interaction.user))
        elif self.action_type == "mute":
            # Para mute, o arquivo pede presets rápidos antes do modal
            view = MutePresetsView(target_user)
            embed = create_embed(title="Silenciar Usuário", description=f"Escolha um tempo rápido ou use o botão personalizado para {target_user.mention}.")
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class MutePresetsView(discord.ui.View):
    def __init__(self, target_user: discord.Member):
        super().__init__(timeout=60)
        self.target_user = target_user

    async def quick_mute(self, interaction: discord.Interaction, duration_str: str):
        embed = create_embed(title="Mute Aplicado", description=f"{self.target_user.mention} foi silenciado por {duration_str}.")
        await interaction.response.edit_message(embed=embed, view=None)

    @discord.ui.button(label="5m", style=discord.ButtonStyle.secondary)
    async def m5(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.quick_mute(interaction, "5 minutos")

    @discord.ui.button(label="30m", style=discord.ButtonStyle.secondary)
    async def m30(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.quick_mute(interaction, "30 minutos")

    @discord.ui.button(label="1h", style=discord.ButtonStyle.secondary)
    async def h1(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.quick_mute(interaction, "1 hora")

    @discord.ui.button(label="Personalizado", style=discord.ButtonStyle.secondary)
    async def custom(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(MuteModal(self.target_user))

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ban", description="Bane um usuário")
    async def ban(self, interaction: discord.Interaction):
        view = UserSelectView("ban")
        await interaction.response.send_message("Selecione o usuário para BANIR:", view=view, ephemeral=True)

    @app_commands.command(name="kick", description="Expulsa um usuário")
    async def kick(self, interaction: discord.Interaction):
        view = UserSelectView("kick")
        await interaction.response.send_message("Selecione o usuário para EXPULSAR:", view=view, ephemeral=True)

    @app_commands.command(name="mute", description="Silencia um usuário")
    async def mute(self, interaction: discord.Interaction):
        view = UserSelectView("mute")
        await interaction.response.send_message("Selecione o usuário para SILENCIAR:", view=view, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Moderation(bot))
