import discord
from discord import app_commands
from discord.ext import commands
from utils.constants import create_embed

class Utilities(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="lock", description="Trava o canal atual ou selecionado")
    async def lock(self, interaction: discord.Interaction):
        view = ChannelSelectView("lock")
        await interaction.response.send_message("Selecione os canais para TRAVAR:", view=view, ephemeral=True)

    @app_commands.command(name="unlock", description="Destrava o canal")
    async def unlock(self, interaction: discord.Interaction):
        view = ChannelSelectView("unlock")
        await interaction.response.send_message("Selecione os canais para DESTRAVAR:", view=view, ephemeral=True)

    @app_commands.command(name="slowmode", description="Configura o modo lento")
    async def slowmode(self, interaction: discord.Interaction):
        view = SlowmodeSelectView()
        await interaction.response.send_message("Selecione o tempo do modo lento:", view=view, ephemeral=True)

    @app_commands.command(name="clear", description="Limpa mensagens do canal")
    async def clear(self, interaction: discord.Interaction):
        modal = ClearModal()
        await interaction.response.send_modal(modal)

class ChannelSelectView(discord.ui.View):
    def __init__(self, action: str):
        super().__init__(timeout=60)
        self.action = action

    @discord.ui.select(cls=discord.ui.ChannelSelect, placeholder="Selecione os canais...", min_values=1, max_values=5)
    async def select_channels(self, interaction: discord.Interaction, select: discord.ui.ChannelSelect):
        channels = select.values
        # Lógica de lock/unlock aqui
        action_text = "travados" if self.action == "lock" else "destravados"
        embed = create_embed(title="Canais Atualizados", description=f"{len(channels)} canais foram {action_text} com sucesso.")
        await interaction.response.send_message(embed=embed, ephemeral=True)

class SlowmodeSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(
        placeholder="Escolha o tempo...",
        options=[
            discord.SelectOption(label="Off", value="0"),
            discord.SelectOption(label="5s", value="5"),
            discord.SelectOption(label="10s", value="10"),
            discord.SelectOption(label="30s", value="30"),
            discord.SelectOption(label="1m", value="60"),
            discord.SelectOption(label="5m", value="300"),
        ]
    )
    async def callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        seconds = int(select.values[0])
        await interaction.channel.edit(slowmode_delay=seconds)
        embed = create_embed(title="Slowmode Atualizado", description=f"O modo lento foi definido para {seconds} segundos.")
        await interaction.response.send_message(embed=embed, ephemeral=True)

class ClearModal(discord.ui.Modal, title='Limpeza de Mensagens'):
    quantidade = discord.ui.TextInput(label='Quantidade', placeholder='Ex: 50', required=True)
    usuario = discord.ui.TextInput(label='ID do Usuário (Opcional)', required=False)

    async def on_submit(self, interaction: discord.Interaction):
        amount = int(self.quantidade.value)
        # Lógica de purge aqui
        embed = create_embed(title="Limpeza Concluída", description=f"{amount} mensagens foram removidas.")
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Utilities(bot))
