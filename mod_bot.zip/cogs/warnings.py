import discord
from discord import app_commands
from discord.ext import commands
from utils.constants import create_embed
import uuid

class WarnModal(discord.ui.Modal, title='Aplicar Advertência'):
    motivo = discord.ui.TextInput(label='Motivo', style=discord.TextStyle.paragraph, required=True)
    evidencias = discord.ui.TextInput(label='Evidências (Link)', required=False)

    def __init__(self, target_user: discord.Member, severidade: str):
        super().__init__()
        self.target_user = target_user
        self.severidade = severidade

    async def on_submit(self, interaction: discord.Interaction):
        warn_id = str(uuid.uuid4())[:8]
        # Aqui salvaria no DB
        embed = create_embed(
            title="Advertência Aplicada",
            description=f"Usuário: {self.target_user.mention}\nSeveridade: **{self.severidade}**\nMotivo: {self.motivo.value}\nID: `{warn_id}`"
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

class WarnSeveritySelect(discord.ui.View):
    def __init__(self, target_user: discord.Member):
        super().__init__(timeout=60)
        self.target_user = target_user

    @discord.ui.select(
        placeholder="Selecione a severidade...",
        options=[
            discord.SelectOption(label="Baixa", value="Baixa"),
            discord.SelectOption(label="Média", value="Média"),
            discord.SelectOption(label="Alta", value="Alta"),
            discord.SelectOption(label="Grave", value="Grave"),
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        await interaction.response.send_modal(WarnModal(self.target_user, select.values[0]))

class Warnings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="warn", description="Aplica uma advertência a um usuário")
    async def warn(self, interaction: discord.Interaction):
        view = UserSelectWarnView()
        await interaction.response.send_message("Selecione o usuário para advertir:", view=view, ephemeral=True)

    @app_commands.command(name="warnings", description="Mostra o histórico de advertências")
    async def show_warnings(self, interaction: discord.Interaction, user: discord.User):
        # Simulação de histórico com paginação
        embed = create_embed(
            title=f"Histórico de {user.name}",
            description="Total de advertências: 0\n\n*Nenhum registro encontrado.*"
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

class UserSelectWarnView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder="Selecione um usuário...")
    async def select_user(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        view = WarnSeveritySelect(select.values[0])
        await interaction.response.send_message("Selecione a severidade da advertência:", view=view, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Warnings(bot))
