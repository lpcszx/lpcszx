import discord
from discord.ext import commands
import os
import asyncio
import logging

# Configuração de logs
logging.basicConfig(level=logging.INFO)

class ModBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = True
        intents.guilds = True
        
        super().__init__(
            command_prefix="!",
            intents=intents,
            help_command=None
        )

    async def setup_hook(self):
        # Carregar extensões (Cogs)
        for filename in os.listdir('./cogs'):
            if filename.endswith('.py'):
                await self.load_extension(f'cogs.{filename[:-3]}')
        
        # Sincronizar comandos slash
        await self.tree.sync()
        print(f"Comandos sincronizados para {self.user}")

    async def on_ready(self):
        print(f'Bot logado como {self.user} (ID: {self.user.id})')
        print('------')

async def main():
    bot = ModBot()
    # O token deve ser configurado pelo usuário
    # await bot.start('YOUR_TOKEN_HERE')
    print("Bot inicializado. Configure o token para rodar.")

if __name__ == "__main__":
    asyncio.run(main())
